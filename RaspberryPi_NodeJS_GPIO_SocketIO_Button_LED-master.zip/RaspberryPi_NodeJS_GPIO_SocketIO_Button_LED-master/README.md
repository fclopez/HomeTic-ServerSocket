Raspberry Pi B+

Node.js

onoff (GPIO)

Socket.io

Button input

Led control

Web frontend